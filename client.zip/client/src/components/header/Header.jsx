import React from 'react'
import './Header.css'
import Search from '../searchBar/Search'
// import ProfilePage from '../../pages/profile/Profile'

const Header = () => {
  return (
    <div className="header">
        <span className='logo'>Social.WE</span>
<Search/>
<span className='userIcon'>i</span>
    </div>
  )
}

export default Header