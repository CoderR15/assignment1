import React from 'react'
import { PostsData } from '../../Data/PostData'
import CreatedPost from '../createdPost/CreatedPost'
import './SharedPosts.css'
const SharedPosts = () => {
  return (
    <div className="sharedPosts">
       {PostsData.map((post, id)=>{
        return <CreatedPost data={post} id={id}/>
       })}
    </div>
  )
}

export default SharedPosts