import React, {useState, useRef} from 'react'
import './Post.css'
import ProfileImg from '../../images/dp3.jpg'
import InsertPhotoIcon from '@mui/icons-material/InsertPhoto';
import ClearIcon from '@mui/icons-material/Clear';

const Post = () => {
    const [image, setImage]= useState(null)
    const imageRef = useRef()

    const onImageChange =(event)=>{
        if(event.target.files && event.target.files[0]){
            let img = event.target.files[0];
            setImage({
                image: URL.createObjectURL(img),
            });
        }

    };

    return (
        <div className="post">
            <div className="post-wrap">
            <img src={ProfileImg} alt="" />
            <div className='input-wrap'>
                <input type="text" name="" id="" placeholder='What are you thinking?' />
            <span className="postImg" onClick={()=>imageRef.current.click()}>
            <InsertPhotoIcon/>
              Upload  Photo
            </span>
            </div>
           <button className='share'>
            >
           </button>

           <div style={{display:"none"}}><input type="file" name="imagePost" ref={imageRef} onChange={onImageChange}/>
           </div>
</div>
           {image && (
            <div className="previewImage">
                <ClearIcon onClick={()=>setImage(null)}/>
                <img src={image.image} alt="" />
            </div>
           )}
           
        </div>
    
    )
}

export default Post