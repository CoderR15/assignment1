import React from 'react'
import './ProfileCard.css'
import CoverPic from '../../images/img2.jpg'
import ProfilePic from '../../images/dp3.jpg'


const ProfileCard = () => {
  return (
    <div className="profile">
      <div className="profileCard">
        <div className="profileImg">
          <img src={CoverPic} alt="" />
          <img src={ProfilePic} alt="" />
          <div className="profileName">
            <span>Jennifer</span>
            <span>UI/UX Designer</span>
          </div>
        </div>
        <div className="followCount">

          
            <div className="follower-count">
              <span>11K  </span>
              <span>Followers</span>
            </div>
            <div className="following-count">
              <span>1.4K  </span>
              <span> Following </span>
            </div>
          

        </div>



      </div>
    </div>
  )
}

export default ProfileCard