import React from 'react'
import SharedPosts from '../sharedPost/SharedPosts'
import Post from '../userPost/Post'
import './Mid.css'

const Mid = () => {
  return (
    <div className='mid-wrap'>
    <div className="post">
    <Post/>
  </div>
    <div className="mid">
       <SharedPosts/>
    </div>
    </div>
  )
}

export default Mid 