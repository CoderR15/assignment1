import React from 'react'
import './CreatedPost.css'
import Comment from '../../images/comment.png'
import Liked from '../../images/filledheart.png'
import Share from '../../images/share.png'
import NotLiked from '../../images/heart.png'

const CreatedPost = ({data}) => {
  return (
    <div className="createdPost">
        <img src={data.img} alt="" />


        <div className="reaction">
            <img src={data.liked?Liked: NotLiked} alt="" />
            <img src={Comment} alt="" />
            <img src={Share} alt="" />
        </div>

        <span>{data.likes} likes </span>

        <div className="detail">
            <span><b>{data.name}</b></span>
            <span> {data.desc}</span>
        </div>

    </div>
  )
}

export default CreatedPost