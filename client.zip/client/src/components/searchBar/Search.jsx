import React from 'react'
import './Search.css'
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
const Search = () => {
  return (
    <div className="search">
      <input type="text" placeholder='Enter text to search..' />
      <span className="searchIcon">
        <SearchOutlinedIcon />
      </span>
    </div>
  )
}
// color="action"
export default Search