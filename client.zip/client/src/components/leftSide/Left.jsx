import React from 'react'
import './Left.css'
import {Followers} from '../../Data/FollowersData'
const Left = () => {
  return (
  <div className="left">

    <h3>Friends</h3>

    {Followers.map((follower, id)=>{
      return(
        <div className="follower"> 
            <div className='follower-wrap'>
              <img src={follower.img} alt="" className='followerImg'/>
              <div className="name">
                <span>{follower.name}</span>
              </div>
            </div>
        </div>
      )
    })}

  </div>
  )
}

export default Left