import Pic1 from '../images/post1.jpg'

export const PostsData = [
    {
        img: Pic1,
        name: 'Miley',
        desc : "Hiring for interns",
        likes:200,
        liked: true
    }
]