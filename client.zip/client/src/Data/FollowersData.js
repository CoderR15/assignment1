import img1 from '../images/dp4.png'
import img2 from '../images/dp6.png'
import img3 from '../images/dp1.jpg'
import img4 from '../images/dp.png'

export const Followers = [
    { name: "James Falcon", username: "James",  img:img1 },
    { name: "George Tanks", username: "George",  img:img2 },
    { name: "Sasha Dukes", username: "Sashaa",  img:img3 },
    { name: "Miley Donut", username: "Miley",  img:img4 }
];