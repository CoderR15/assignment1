import React from 'react'
import './Home.css'
import ProfileCard from '../../components/rightSide/ProfileCard'
import Mid from '../../components/midSide/Mid'
import Left from '../../components/leftSide/Left'

const Home = () => {
  return (
    <div className="Home">
      
        {/* <div className="leftSide">Left</div> */}
        <Left/>
        {/* <div className="midSide">Posts</div> */}
        <Mid/>
        {/* <div className="rightSide">Profile</div> */}
        <ProfileCard/>
    </div>
  )
}

export default Home