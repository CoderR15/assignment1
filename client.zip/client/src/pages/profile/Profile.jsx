import React from 'react'
import Left from '../../components/leftSide/Left'
import ProfileCard from '../../components/rightSide/ProfileCard'
import './Profile.css'

import ProfilePic from '../../images/dp3.jpg'
const Profile = () => {
  return (
    <div className="user-profile">

    <ProfileCard/>

<div className="info">
    <h3>Information</h3>
    <img src={ProfilePic} alt="" />
    <span><b>Name : </b>
    Jennifer Simpson</span>
    <br />
    <span><b>Location : </b>
    Washington</span>
    <br />
    <span><b>Skill : </b>
    UI/UX design</span>
    <br />
    <span><b>Experience : </b>
   3 years</span>
    <br />
  
</div>

    <Left/>

    {/* <div className="front">
        <div className="profileImg">
          <img src={CoverPic} alt="" />
          <img src={ProfilePic} alt="" />
        </div>
    </div> */}
 
</div>
  )
}

export default Profile