import React, {useState} from 'react'
import './Auth.css'
import PagePic from '../../images/meeting.jpg'

const Auth = () => {
    const [isSignUp, setIsSignUp] = useState(false);

    const [data, setData] = useState({name:"", email:"", username:"", password:""})

    const handleChange = (e) =>{
        setData({...data, [e.target.name]:e.target.value})
    }

    const handleSubmit=(e)=>{
        e.preventDefault();

        // if(isSignUp){
        //     data.password
        // }
    }

    return (
        <div className="auth">
            {/* <Signin /> */}
 <form className='userform' onSubmit={handleSubmit}>
            <div className="signup">
               

            <div className="front"><img src={PagePic} alt="" /></div>

            <div className="right-side">
                <div class="log"><div class="lo"> </div> SOCIAL.WE</div>
                <h1>{isSignUp ? "Sign up":"Log In"} Now!</h1>
                {isSignUp &&
                <div>
                <input type="text" name="name" id="nam" placeholder="Name" onChange={handleChange}/>
                <input type="text" name="email" id="mail" placeholder="Email" onChange={handleChange}/>
                </div>
                }
                
                
                <input type="text" name="username" id="uname" placeholder="Username" onChange={handleChange}/>
               
                <input type="password" name="password" id="pass" placeholder="Password" onChange={handleChange}/>
                <button type="Submit"  className="btn" > {isSignUp? "Sign Up":"Log In"}</button>
                <span onClick={()=>setIsSignUp((prev)=>!prev)}>  {isSignUp?"Already have an account? Log In":"Don't have an account? Sign Up"} </span>
            </div>

        </div></form>
        </div> 
    )
}

// function Signup() {
//     return (
//         <div className="signup">

//             <div class="front"><img src={PagePic} alt="" /></div>

//             <div class="right-side">
//                 <div class="log"><div class="lo"> </div> SOCIAL.WE</div>
//                 <h1>Signup Now</h1>
//                 <input type="text" name="Your Name" id="nam" placeholder="Name" />
//                 <input type="text" name="Your Email" id="mail" placeholder="Email" />
//                 <input type="text" name="Username" id="uname" placeholder="Username" />
//                 <input type="password" name="Password" id="pass" placeholder="Password" />
//                 <input type="button" value="Submit" class="btn" />
//                 <p>    Already have an account? <a href="">Sign Up</a></p>
//             </div>

//         </div>
//     )
// }

// function Signin() {
//     return (
//         <div className="signin">

//             <div class="front"><img src={PagePic} alt="" /></div>

//             <div class="right-side">
//                 <div class="log"><div class="lo"> </div> SOCIAL.WE</div>
//                 <h1>Sign In Now</h1>
                
//                 <input type="text" name="Your Email" id="mail" placeholder="Email" />
//                 <input type="password" name="Password" id="pass" placeholder="Password" />
//                 <input type="button" value="Submit" class="btn" />
//                 <p>    Don't have an account? <a href="">Sign Up</a></p>
//             </div>

//         </div>
//     )
// }


export default Auth