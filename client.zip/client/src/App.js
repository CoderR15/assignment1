// import logo from './logo.svg';
import './App.css';
import Header from './components/header/Header'
import Auth from './pages/auth/Auth';
import Home from './pages/home/Home'
import Profile from './pages/profile/Profile';

function App() {
  return (
    <div className="App">
        <Header/>
      
      {/* <Home/> */}
      <Profile/>
      {/* <Auth/> */}
    </div>
  );
}

export default App;
