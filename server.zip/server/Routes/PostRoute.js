import express from "express";
import { createPost, deletePost, getPost, likePost, getFeedPosts } from "../Controllers/PostController.js";
const router = express.Router()

// router.get('/', async(req, res)=>{
//     res.send("Postroute")
// })
 router.post('/', createPost)
 router.get('/:id', getPost)
 router.delete('/:id', deletePost)
 router.put('/:id/like', likePost)
// router.get('./:id/feed', getFeedPosts)

export default router;